This is the supporting code for the final chapter of Selenium Simplified.

It represents a production like test project using JUnit and Selenium-RC

The lib folder contains the required libraries:
- Selenium-RC v1.0.3 from http://seleniumhq.org/download/
- JUnit 4.8.1 from http://www.junit.org/

These libraries are copyright via their respective authors - check the above websites for details.

The source code is publicly hosted at http://svn2.xp-dev.com/svn/seleniumsimplified/trunk/FinalSeleniumTests using the free public hosting service provided by http://xp-dev.com

The source code for the tests and supporting classes in src folder is copyright of Alan Richardson of Compendium Developments 2010
